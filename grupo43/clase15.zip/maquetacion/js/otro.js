import { imprimir, resta, suma } from './clase14.js'

imprimir('43')

suma('3', '2')
resta('3', '2')